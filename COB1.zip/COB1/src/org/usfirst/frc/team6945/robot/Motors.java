package org.usfirst.frc.team6945.robot;

import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;


public class Motors {

	static WPI_TalonSRX _frontLeftMotor = new WPI_TalonSRX(4); 		/* device IDs here */
	static WPI_TalonSRX _frontRightMotor = new WPI_TalonSRX(2);
	static WPI_TalonSRX _backLeftMotor = new WPI_TalonSRX(1);
	static WPI_TalonSRX _backRightMotor = new WPI_TalonSRX(3);	
	static WPI_TalonSRX _scissorLift = new WPI_TalonSRX(5);
	
	static DifferentialDrive _drive = new DifferentialDrive( _frontRightMotor,_frontLeftMotor);
}
