package org.usfirst.frc.team6945.robot;

import com.ctre.phoenix.motorcontrol.can.*;
import edu.wpi.first.wpilibj.BuiltInAccelerometer;
import edu.wpi.first.wpilibj.CameraServer;
import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.PIDSubsystem;




/**

 * The VM is configured to automatically run this class, and to call the

 * functions corresponding to each mode, as described in the IterativeRobot

 * documentation. If you change the name of this class or the package after

 * creating this project, you must also update the manifest file in the resource

 * directory.

 */

public class Robot extends IterativeRobot {

	
	BuiltInAccelerometer rioAccel;		

	Joystick _joy = new Joystick(1);
	Joystick controller = new Joystick(0);
	
	Timer m_timer = new Timer();

	int secondsPerMeter; 
    /**
     * This function is run when the robot is first started up and should be
     * used for any initialization code.
     */

    public void robotInit() {
    	// take our extra talons and just have them follow the Talons updated in arcadeDrive 
    	//_backLeftMotor.follow(_frontLeftMotor);
    	//_backRightMotor.follow(_frontRightMotor); 	   	

    	/*_rightSlave1.follow(_frontRightMotor);
    	_rightSlave2.follow(_frontRightMotor);*/
    	
    	CameraServer.getInstance().startAutomaticCapture();

    }


	/**
	 * This function is run once each time the robot enters autonomous mode.
	 */
	@Override
	public void autonomousInit() {
		m_timer.reset();
		m_timer.start();
	}

	/**
	 * This function is called periodically during autonomous.
	 */
	@Override
	public void autonomousPeriodic() {
		
		Auto1.AutoFirst(m_timer);
		// Drive for 2 seconds
		/*if (m_timer.get() < (5.0)) {
			_drive.arcadeDrive(0.5, 0.0); // drive forwards half speed
			_scissorLift.set(-0.25);
			
		} else {
			_drive.stopMotor(); // stop robot
			_scissorLift.set(0);
			
		}
		//end drive for 2 seconds*/
	}



    /**
     * This function is called periodically during operator control
     */

    public void teleopPeriodic() {

    	double forward = _joy.getY(); // logitech gampad left X, positive is forward
    	double turn = _joy.getX(); //logitech gampad right X, positive means turn right

    	double lift = controller.getY();
    	 
	  // _scissorLift.set(-0.25*lift);
    	

    	//_drive.arcadeDrive(forward, turn); // if statement prevents multiplying motor power by more than 100% (1.0)
    	 

    }

}