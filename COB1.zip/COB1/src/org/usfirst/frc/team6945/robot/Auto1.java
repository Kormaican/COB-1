package org.usfirst.frc.team6945.robot;


import edu.wpi.first.wpilibj.Timer;

public class Auto1 extends Motors {

		
	public static void AutoFirst(Timer m_timer) {
		
    	_backLeftMotor.follow(_frontLeftMotor);
    	_backRightMotor.follow(_frontRightMotor);
		
		if (m_timer.get() < (5.0)) {
			_drive.arcadeDrive(0.5, 0.0); // drive forwards half speed
			_scissorLift.set(-0.25);
			
		} else {
			_drive.stopMotor(); // stop robot
			_scissorLift.set(0);
			
		}
	}
}
